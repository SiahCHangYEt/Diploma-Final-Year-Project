from flask import Flask, render_template, request, jsonify
import joblib
from newspaper import Article
import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords
from nltk.stem import PorterStemmer
import re

app = Flask(__name__)

# Load trained model & vectorizer
model = joblib.load("final_model.pkl")
vectorizer = joblib.load("final_vectorizer.pkl")

def clean_text(text):
    """Clean and normalize text."""
    if not text:
        return ""
    # Remove extra whitespace
    text = re.sub(r'\s+', ' ', text)
    # Remove special characters but keep basic punctuation
    text = re.sub(r'[^\w\s.,!?-]', '', text)
    return text.strip()


stop_words = set(stopwords.words('english'))

def preprocess_sentence(sentence):
    """Removes stopwords from a sentence."""
    return ' '.join(word for word in sentence.split() if word not in stop_words)

ps = PorterStemmer()
def stemming(text):
    return " ".join([ps.stem(word) for word in text.split()])


def scrape_news(url):
    """Extract article text from a given URL."""
    try:
        article = Article(url)
        article.download()
        article.parse()
        return clean_text(article.text) if article.text else None
    except Exception as e:
        return None

@app.route("/", methods=["GET", "POST"])
def home():
    prediction = None
    result = None
    input_text = ""
    error = None

    if request.method == "POST":
        try:
            text = request.form.get("text", "").strip()
            url = request.form.get("url", "").strip()

            if url:
                article_text = scrape_news(url)
                if article_text:
                    text = article_text
                else:
                    error = "Could not extract article content. Please check the URL and try again."
                    return render_template("index.html", error=error)

            if text:
                # Clean and prepare text
                cleaned_text = clean_text(text)
                if len(cleaned_text) < 200:  # Minimum text length check
                    error = "Please provide more text content for accurate analysis."
                    return render_template("index.html", error=error)
                
                preprocessed_text = preprocess_sentence(cleaned_text)
                preprocessed_text = stemming(preprocessed_text)

                # Transform and predict
                transformed_text = vectorizer.transform([preprocessed_text])
                prediction = model.predict(transformed_text)[0]
                result = "Real News" if prediction == 0 else "Fake News"
                
                # Prepare display text
                input_text = cleaned_text[:500] + "..." if len(cleaned_text) > 500 else cleaned_text
            else:
                error = "Please provide either a URL or text content to analyze."
                return render_template("index.html", error=error)

        except Exception as e:
            error = "An error occurred while processing your request. Please try again."
            return render_template("index.html", error=error)

    return render_template("index.html", 
                         prediction=result, 
                         input_text=input_text,
                         error=error)

@app.errorhandler(404)
def page_not_found(e):
    return render_template("index.html", error="Page not found. Please check the URL."), 404

@app.errorhandler(500)
def internal_server_error(e):
    return render_template("index.html", error="An internal server error occurred. Please try again later."), 500

if __name__ == "__main__":
    app.run(debug=True)


